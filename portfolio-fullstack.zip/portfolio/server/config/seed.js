// server/config/seed.js
// Run: node server/config/seed.js
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./db');
const Profile  = require('../models/Profile');
const Project  = require('../models/Project');
const Skill    = require('../models/Skill');

const profileData = {
  name: 'P Parthasarathi',
  role: 'Frontend Developer',
  roleAccent: 'UI Designer',
  greeting: 'Welcome to my portfolio',
  tagline: 'Smart_think',
  description:
    'I craft fast, accessible, and beautifully designed web experiences. Passionate about clean code, thoughtful design systems, and bringing ideas to life through the browser.',
  location: 'Chennai, India',
  email: 'parthasb423@gmail.com',
  linkedin: 'https://www.linkedin.com/in/parthasarathi-p-a5a515325/',
  github: 'https://github.com/partha-smart-423',
  instagram: 'https://www.instagram.com/parthazz._.95/',
  about: [
    "Hello! I'm Parthasarathi, a frontend developer based in Chennai, India. I specialize in building modern web interfaces that are fast, accessible, and a joy to use. I love turning complex problems into clean, intuitive designs.",
    "My journey began with curiosity about how websites work, and it has evolved into a deep passion for web performance, design systems, and crafting smooth user experiences. I believe great software feels invisible — it just works.",
  ],
  stats: {
    yearsExperience: 3,
    projectsDone: 20,
    happyClients: 15,
  },
  available: true,
};

const skillsData = [
  {
    icon: '🎨',
    category: 'Frontend',
    color: 'gold',
    order: 1,
    items: [
      { name: 'HTML5 / CSS3',       pct: 95 },
      { name: 'JavaScript (ES6+)',  pct: 88 },
      { name: 'React.js',           pct: 82 },
      { name: 'Responsive Design',  pct: 90 },
    ],
  },
  {
    icon: '⚙️',
    category: 'Tools & Backend',
    color: 'teal',
    order: 2,
    items: [
      { name: 'Git / GitHub', pct: 90 },
      { name: 'Node.js',      pct: 72 },
      { name: 'Figma / Design', pct: 78 },
      { name: 'REST APIs',    pct: 80 },
    ],
  },
  {
    icon: '🚀',
    category: 'Soft Skills',
    color: 'rose',
    order: 3,
    items: [
      { name: 'Problem Solving',     pct: 92 },
      { name: 'Team Collaboration',  pct: 88 },
      { name: 'Communication',       pct: 85 },
      { name: 'Fast Learning',       pct: 95 },
    ],
  },
];

const projectsData = [
  {
    title: 'ShopEase — E-Commerce Platform',
    description:
      'A full-featured e-commerce web app with product browsing, cart management, user authentication, and payment integration. Built with React and a Node.js backend.',
    type: 'Featured',
    featured: true,
    image: 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&h=450&fit=crop',
    tech: ['React', 'Node.js', 'MongoDB', 'Stripe API', 'CSS Modules'],
    liveUrl: '#',
    githubUrl: '#',
    order: 1,
  },
  {
    title: 'DataViz Dashboard',
    description:
      'Real-time analytics dashboard with interactive charts, dark/light mode, and responsive layout. Uses Chart.js for data visualization.',
    type: 'Dashboard',
    featured: false,
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=340&fit=crop',
    tech: ['JavaScript', 'Chart.js', 'CSS Grid'],
    liveUrl: '#',
    githubUrl: '#',
    order: 2,
  },
  {
    title: 'Lumina — Gallery App',
    description:
      'A responsive image gallery with masonry layout, category filtering, lightbox viewer, and smooth hover animations.',
    type: 'Mobile UI',
    featured: false,
    image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=340&fit=crop',
    tech: ['HTML', 'CSS', 'Vanilla JS'],
    liveUrl: '#',
    githubUrl: '#',
    order: 3,
  },
  {
    title: 'Calc — Smart Calculator',
    description:
      'A premium calculator with keyboard support, calculation history, chained operations, and beautiful dark UI.',
    type: 'Web App',
    featured: false,
    image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=340&fit=crop',
    tech: ['HTML', 'CSS', 'JavaScript'],
    liveUrl: '#',
    githubUrl: '#',
    order: 4,
  },
];

const seed = async () => {
  await connectDB();
  console.log('🌱 Seeding database…');

  await Profile.deleteMany({});
  await Project.deleteMany({});
  await Skill.deleteMany({});

  await Profile.create(profileData);
  await Skill.insertMany(skillsData);
  await Project.insertMany(projectsData);

  console.log('✅ Seed complete!');
  process.exit(0);
};

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
