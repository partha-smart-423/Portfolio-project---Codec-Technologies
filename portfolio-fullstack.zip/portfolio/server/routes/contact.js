// server/routes/contact.js
const express                        = require('express');
const router                         = express.Router();
const { body }                       = require('express-validator');
const rateLimit                      = require('express-rate-limit');
const { sendMessage }                = require('../controllers/contactController');

// Strict rate limit for the contact endpoint
const contactLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
  max:      parseInt(process.env.CONTACT_RATE_LIMIT_MAX || '5'),
  message:  { success: false, message: 'Too many messages. Please wait 15 minutes and try again.' },
  standardHeaders: true,
  legacyHeaders:   false,
});

const validators = [
  body('firstName').trim().notEmpty().withMessage('First name is required').isLength({ max: 80 }),
  body('lastName').trim().notEmpty().withMessage('Last name is required').isLength({ max: 80 }),
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('subject').optional().trim().isLength({ max: 200 }),
  body('message').trim().notEmpty().withMessage('Message is required').isLength({ min: 10, max: 5000 }),
];

router.post('/', contactLimiter, validators, sendMessage);

module.exports = router;
