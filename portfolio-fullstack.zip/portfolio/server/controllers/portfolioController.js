// server/controllers/portfolioController.js
const Profile = require('../models/Profile');
const Project = require('../models/Project');
const Skill   = require('../models/Skill');

// GET /api/profile
exports.getProfile = async (req, res) => {
  try {
    const profile = await Profile.findOne().lean();
    if (!profile) return res.status(404).json({ success: false, message: 'Profile not found' });
    res.json({ success: true, data: profile });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
};

// GET /api/projects
exports.getProjects = async (req, res) => {
  try {
    const projects = await Project.find().sort({ order: 1, createdAt: -1 }).lean();
    res.json({ success: true, data: projects });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
};

// GET /api/skills
exports.getSkills = async (req, res) => {
  try {
    const skills = await Skill.find().sort({ order: 1 }).lean();
    res.json({ success: true, data: skills });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
};

// GET /api/portfolio  (all-in-one — reduces round trips)
exports.getAll = async (req, res) => {
  try {
    const [profile, projects, skills] = await Promise.all([
      Profile.findOne().lean(),
      Project.find().sort({ order: 1 }).lean(),
      Skill.find().sort({ order: 1 }).lean(),
    ]);
    res.json({ success: true, data: { profile, projects, skills } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error', error: err.message });
  }
};
