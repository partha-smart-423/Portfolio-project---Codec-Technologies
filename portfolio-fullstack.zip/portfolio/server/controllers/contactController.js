// server/controllers/contactController.js
const { validationResult } = require('express-validator');
const nodemailer = require('nodemailer');
const Message    = require('../models/Message');

// Build transporter lazily so it doesn't crash if env vars are missing during dev
let _transporter = null;
const getTransporter = () => {
  if (!_transporter) {
    _transporter = nodemailer.createTransport({
      host:   process.env.SMTP_HOST   || 'smtp.gmail.com',
      port:   parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_PORT === '465',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return _transporter;
};

// POST /api/contact
exports.sendMessage = async (req, res) => {
  // 1. Validate
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ success: false, errors: errors.array() });
  }

  const { firstName, lastName, email, subject, message } = req.body;

  try {
    // 2. Save to MongoDB
    const saved = await Message.create({
      firstName,
      lastName,
      email,
      subject: subject || 'Portfolio Contact',
      message,
      ip: req.ip,
    });

    // 3. Send notification email (non-blocking — don't fail the request if email fails)
    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      const transporter = getTransporter();
      const mailOptions = {
        from: `"Portfolio Contact" <${process.env.SMTP_USER}>`,
        to:   process.env.EMAIL_TO || process.env.SMTP_USER,
        replyTo: email,
        subject: `📬 New message: ${subject || 'Portfolio Contact'} — ${firstName} ${lastName}`,
        html: `
          <div style="font-family:sans-serif;max-width:600px;margin:auto;background:#0c0d10;color:#f0ece3;padding:2rem;border-radius:8px;border:1px solid rgba(255,255,255,0.08)">
            <h2 style="color:#c8a96e;margin-bottom:0.5rem">New Portfolio Message</h2>
            <p style="color:#9a9590;font-size:0.85rem;margin-bottom:2rem">${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}</p>
            <table style="width:100%;border-collapse:collapse">
              <tr><td style="color:#4a4845;padding:0.5rem 0;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.1em;width:100px">From</td><td style="color:#f0ece3">${firstName} ${lastName}</td></tr>
              <tr><td style="color:#4a4845;padding:0.5rem 0;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.1em">Email</td><td><a href="mailto:${email}" style="color:#2dd4bf">${email}</a></td></tr>
              <tr><td style="color:#4a4845;padding:0.5rem 0;font-size:0.78rem;text-transform:uppercase;letter-spacing:0.1em">Subject</td><td style="color:#f0ece3">${subject || '—'}</td></tr>
            </table>
            <hr style="border:none;border-top:1px solid rgba(255,255,255,0.06);margin:1.5rem 0"/>
            <p style="color:#9a9590;white-space:pre-wrap">${message}</p>
            <hr style="border:none;border-top:1px solid rgba(255,255,255,0.06);margin:1.5rem 0"/>
            <p style="color:#4a4845;font-size:0.75rem">Message ID: ${saved._id}</p>
          </div>
        `,
      };

      transporter.sendMail(mailOptions).catch(err => {
        console.warn('⚠️  Email send failed (message still saved):', err.message);
      });
    } else {
      console.info('ℹ️  SMTP not configured — skipping email notification');
    }

    res.status(201).json({
      success: true,
      message: 'Your message has been received! I\'ll get back to you soon.',
      id: saved._id,
    });
  } catch (err) {
    console.error('Contact error:', err);
    res.status(500).json({ success: false, message: 'Failed to send message. Please try again.' });
  }
};
