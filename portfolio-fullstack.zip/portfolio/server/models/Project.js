// server/models/Project.js
const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema(
  {
    title:       { type: String, required: true },
    description: { type: String, required: true },
    type:        { type: String, default: 'Web App' },
    featured:    { type: Boolean, default: false },
    image:       { type: String },
    tech:        [{ type: String }],
    liveUrl:     { type: String },
    githubUrl:   { type: String },
    order:       { type: Number, default: 99 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Project', projectSchema);
