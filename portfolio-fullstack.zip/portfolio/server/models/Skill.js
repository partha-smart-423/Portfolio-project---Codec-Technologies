// server/models/Skill.js
const mongoose = require('mongoose');

const skillSchema = new mongoose.Schema(
  {
    icon:     { type: String },
    category: { type: String, required: true },
    color:    { type: String, default: 'gold' },
    order:    { type: Number, default: 99 },
    items: [
      {
        name: { type: String, required: true },
        pct:  { type: Number, min: 0, max: 100, required: true },
      },
    ],
  },
  { timestamps: true }
);

module.exports = mongoose.model('Skill', skillSchema);
