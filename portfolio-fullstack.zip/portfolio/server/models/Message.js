// server/models/Message.js
const mongoose = require('mongoose');

const messageSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true, trim: true, maxlength: 80 },
    lastName:  { type: String, required: true, trim: true, maxlength: 80 },
    email:     { type: String, required: true, trim: true, lowercase: true, maxlength: 200 },
    subject:   { type: String, trim: true, maxlength: 200 },
    message:   { type: String, required: true, trim: true, maxlength: 5000 },
    ip:        { type: String },
    read:      { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Message', messageSchema);
