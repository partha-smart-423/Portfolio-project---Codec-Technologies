// server/models/Profile.js
const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema(
  {
    name:        { type: String, required: true },
    role:        { type: String, required: true },
    roleAccent:  { type: String },
    greeting:    { type: String },
    tagline:     { type: String },
    description: { type: String },
    location:    { type: String },
    email:       { type: String },
    linkedin:    { type: String },
    github:      { type: String },
    instagram:   { type: String },
    about:       [{ type: String }],
    stats: {
      yearsExperience: { type: Number, default: 0 },
      projectsDone:    { type: Number, default: 0 },
      happyClients:    { type: Number, default: 0 },
    },
    available: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Profile', profileSchema);
