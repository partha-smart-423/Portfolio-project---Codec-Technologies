// server/index.js
require('dotenv').config();

const express    = require('express');
const path       = require('path');
const helmet     = require('helmet');
const cors       = require('cors');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const connectDB  = require('./config/db');

const portfolioRoutes = require('./routes/portfolio');
const contactRoutes   = require('./routes/contact');

const app  = express();
const PORT = process.env.PORT || 3000;

/* ------------------------------------------------------------------ */
/*  Database                                                            */
/* ------------------------------------------------------------------ */
connectDB();

/* ------------------------------------------------------------------ */
/*  Security & middleware                                               */
/* ------------------------------------------------------------------ */
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        styleSrc:   ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc:    ["'self'", 'https://fonts.gstatic.com'],
        imgSrc:     ["'self'", 'data:', 'https:'],
        scriptSrc:  ["'self'", "'unsafe-inline'"],
        connectSrc: ["'self'"],
      },
    },
  })
);

app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.ALLOWED_ORIGIN || false   // set ALLOWED_ORIGIN=https://yourdomain.com
    : true,
}));

app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// Global rate limit
app.use(
  rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
    max:      parseInt(process.env.RATE_LIMIT_MAX        || '100'),
    standardHeaders: true,
    legacyHeaders:   false,
  })
);

/* ------------------------------------------------------------------ */
/*  Static files                                                        */
/* ------------------------------------------------------------------ */
app.use(express.static(path.join(__dirname, '..', 'public')));

/* ------------------------------------------------------------------ */
/*  API routes                                                          */
/* ------------------------------------------------------------------ */
app.use('/api', portfolioRoutes);
app.use('/api/contact', contactRoutes);

// Health-check endpoint
app.get('/api/health', (req, res) =>
  res.json({ status: 'ok', time: new Date().toISOString() })
);

/* ------------------------------------------------------------------ */
/*  SPA fallback — serve index.html for all non-API routes             */
/* ------------------------------------------------------------------ */
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
  } else {
    res.status(404).json({ success: false, message: 'API route not found' });
  }
});

/* ------------------------------------------------------------------ */
/*  Error handler                                                       */
/* ------------------------------------------------------------------ */
app.use((err, req, res, _next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
});

/* ------------------------------------------------------------------ */
/*  Start                                                               */
/* ------------------------------------------------------------------ */
app.listen(PORT, () => {
  console.log(`\n🚀  Server running on http://localhost:${PORT}`);
  console.log(`📦  Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔑  Seed DB: npm run seed\n`);
});
