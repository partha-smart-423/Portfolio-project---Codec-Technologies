# Parthasarathi — Full-Stack Portfolio

A production-grade personal portfolio with a **Node.js + Express** backend, **MongoDB** database, RESTful API, email integration, and a beautiful responsive frontend.

---

## 🗂 Project Structure

```
portfolio/
├── server/
│   ├── config/
│   │   ├── db.js          # MongoDB connection
│   │   └── seed.js        # DB seed script
│   ├── controllers/
│   │   ├── portfolioController.js
│   │   └── contactController.js
│   ├── models/
│   │   ├── Profile.js
│   │   ├── Project.js
│   │   ├── Skill.js
│   │   └── Message.js
│   ├── routes/
│   │   ├── portfolio.js
│   │   └── contact.js
│   └── index.js           # Express app entry point
├── public/
│   └── index.html         # Frontend (served as static file)
├── .env.example           # Environment variable template
├── .gitignore
└── package.json
```

---

## 🚀 Quick Start

### 1. Prerequisites
- Node.js ≥ 18
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) free tier)

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment variables
```bash
cp .env.example .env
```
Edit `.env` and fill in:
- `MONGO_URI` — your MongoDB connection string
- `SMTP_USER` / `SMTP_PASS` — Gmail App Password (optional, for email notifications)
- `EMAIL_TO` — your email to receive contact messages

### 4. Seed the database
```bash
npm run seed
```
This populates MongoDB with your profile, projects, and skills.

### 5. Start the server
```bash
# Development (auto-restart on changes)
npm run dev

# Production
npm start
```

Visit **http://localhost:3000** 🎉

---

## 🔌 API Endpoints

| Method | Endpoint         | Description                      |
|--------|-----------------|----------------------------------|
| GET    | `/api/health`   | Server health check              |
| GET    | `/api/portfolio`| All data (profile + projects + skills) |
| GET    | `/api/profile`  | Profile data                     |
| GET    | `/api/projects` | Projects list                    |
| GET    | `/api/skills`   | Skills list                      |
| POST   | `/api/contact`  | Submit contact form              |

### POST `/api/contact` — Request body
```json
{
  "firstName": "Jane",
  "lastName":  "Doe",
  "email":     "jane@example.com",
  "subject":   "Project Inquiry",
  "message":   "Hi! I'd love to work with you..."
}
```

---

## 📧 Email Setup (Gmail)

1. Enable 2-Factor Authentication on your Google account
2. Go to **Google Account → Security → App Passwords**
3. Create a new App Password for "Mail"
4. Copy the 16-character password into `.env` as `SMTP_PASS`

---

## 🌐 Deployment (Render / Railway / Fly.io)

1. Push to GitHub
2. Connect repo to your hosting provider
3. Set environment variables in the dashboard
4. Set build command: `npm install`
5. Set start command: `npm start`
6. Run seed once: `node server/config/seed.js`

---

## 🔒 Security Features
- **Helmet.js** — HTTP security headers
- **Rate limiting** — 100 req/15min globally; 5 req/15min on `/api/contact`
- **express-validator** — Server-side input validation
- **Environment variables** — No hardcoded secrets
- **MongoDB sanitization** — Mongoose schemas enforce types/limits
